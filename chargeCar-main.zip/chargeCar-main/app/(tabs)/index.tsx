// index.tsx
import React from 'react';
import Routes from '../routes'; // ajuste conforme sua pasta

export default function App() {
  return <Routes />;
}
